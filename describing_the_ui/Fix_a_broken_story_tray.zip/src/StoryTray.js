export default function StoryTray({ stories }) {
  let sotriesCopy = stories.slice();
  sotriesCopy.push({
    id: 'create',
    label: 'Create Story'
  });

  return (
    <ul>
      {sotriesCopy.map(story => (
        <li key={story.id}>
          {story.label}
        </li>
      ))}
    </ul>
  );
}
