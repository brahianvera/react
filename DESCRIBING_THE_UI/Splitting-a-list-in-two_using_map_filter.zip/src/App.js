import { people } from "./data.js";
import { getImageUrl } from "./utils.js";

let ListScientific = ({ people }) => {
  console.log(people);
  return (
    <>
      {people.map((person) => (
        <li key={person.id}>
          <img src={getImageUrl(person)} alt={person.name} />
          <p>
            <b>{person.name}:</b>
            {" " + person.profession + " "}
            known for {person.accomplishment}
          </p>
        </li>
      ))}
    </>
  );
};

export default function List() {
  const chemist = people.filter((person) => person.profession === "chemist");
  const otherProfession = people.filter(
    (person) => person.profession !== "chemist"
  );
  //const listOtherProfession = listScientific(otherProfession);
  return (
    <article>
      <h1>Chemist</h1>
      <ul>
        <ListScientific people={chemist} />
      </ul>
      <h1>Other Scientists</h1>
      <h1>
        <ListScientific people={otherProfession} />{" "}
      </h1>
    </article>
  );
}
